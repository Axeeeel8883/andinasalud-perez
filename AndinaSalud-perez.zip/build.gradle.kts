plugins {
    kotlin("multiplatform") version "2.1.21" apply false
    kotlin("android") version "2.1.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.1.21" apply false
    id("org.jetbrains.compose") version "1.7.3" apply false
    id("com.android.library") version "8.8.2" apply false
    id("com.android.application") version "8.8.2" apply false
}
