import SwiftUI
import Shared

@main
struct AndinaSaludApp: App {
    var body: some Scene {
        WindowGroup { ComposeView().ignoresSafeArea(.keyboard) }
    }
}

struct ComposeView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> UIViewController {
        MainViewControllerKt.MainViewController()
    }
    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {}
}
